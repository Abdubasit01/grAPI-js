# grAPI

**grAPI** is a stealthy and aggressive unified API recon tool for endpoint discovery, passive & active reconnaissance, token detection, and spec scanning.

## Installation

```bash
pip install .
```

## Usage

```bash
grapi --url https://example.com --all
```

## Features

- Passive recon via Wayback Machine
- WAF & fingerprint detection
- Swagger/OpenAPI & GraphQL detection
- JS token scanning
- JSON/txt report output
